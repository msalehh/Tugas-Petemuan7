var arr = ["Sandhika", "Galih", "Nova"];

for (var i = 0; i < 3; i++) {
	console.log('Mahasiswa ke-' + i + ' : ' + arr[i]) ;
	
}