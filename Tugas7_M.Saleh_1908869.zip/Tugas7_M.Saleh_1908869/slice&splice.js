var arr = ['Sandhika', 'Galih', 'Nova', 'Doddy', 'Fitri']; 

var arr2 = arr.slice(1,4);
console.log(arr2.join(' - '));