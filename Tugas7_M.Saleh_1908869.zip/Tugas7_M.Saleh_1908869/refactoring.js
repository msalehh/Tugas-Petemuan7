function jumlahvolumeduakubus(a,b) {
	var volumeA;
	var volumeB;
	var total;
	
	volumeA = ;
	volumeB b * b * b;
	
	total = a * a * a + volumeB;
	return total;
}

alert(jumlahvolumeduakubus(8, 3));