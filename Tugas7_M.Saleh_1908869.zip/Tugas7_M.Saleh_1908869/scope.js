var a = 1;

function tes(a) {
	console.log(a);
}

tes(a);
console.log(a);