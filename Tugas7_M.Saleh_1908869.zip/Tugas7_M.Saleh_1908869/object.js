var mhs1 = {
	nama : 'Sandhika Galih',
	nrp : '08765454465',
	email : 'sandikaaalih@upi.edu',
	jurusan : 'Teknik Informatika'
}
var mhs2 = {
	nama : 'Doddy',
	nrp : '05435789907',
	email : 'dodddy@gmail.com',
	jurusan : 'Teknik Industri'
}