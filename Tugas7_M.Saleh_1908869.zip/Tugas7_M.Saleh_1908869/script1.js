var tes = confirm('kamu yakin ingin melanjutkan??');
if(tes === true ){
	alert('silahakan tekan OK!');
}else{
	alert('user menekan CANCEL!');
}